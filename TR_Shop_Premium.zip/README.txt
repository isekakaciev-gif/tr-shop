Переименуйте ваши фотографии:
nike-blue.jpg
levi-white.jpg
tommy.jpg
bmw.jpg
newbalance.jpg
lacoste.jpg
car-hoodie.jpg